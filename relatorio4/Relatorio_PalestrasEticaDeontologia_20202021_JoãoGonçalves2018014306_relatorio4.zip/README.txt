a diferença entre os dois é que um pdf foi feito em dark mode para ser mais leve para ler no computador e o outro tem as cores em branco normal para imprimir 
